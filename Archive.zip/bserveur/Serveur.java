package bserveur;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Serveur extends Thread {
    private ServerSocket serverSocket;

    private Class<? extends Service> serviceClass;

    public Serveur(Class<? extends Service> serviceInversionClass, int port) throws IOException, InstantiationException, IllegalAccessException {
        this.serviceClass = serviceInversionClass;
        serverSocket = new ServerSocket(port);
    }

    @Override
    public void run() {
        while (true) {
            try {
                Socket client_socket = serverSocket.accept();
                Service service = serviceClass.newInstance();
                service.setSocket(client_socket);
                new Thread(service).start();
                System.err.println("Client connecte au port " + this.serverSocket.getLocalPort());
            } catch (IOException | InstantiationException | IllegalAccessException e) {
                System.out.println("Erreur client connection: " + e.getMessage());
            }
        }
    }



    public void close() {
        try {
            this.serverSocket.close();
        } catch (IOException e) {
            System.out.println("Erreur fermeture server socket: " + e.getMessage());
        }
    }
}