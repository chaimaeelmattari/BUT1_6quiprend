package serveurInversion;
import bserveur.Serveur;

import java.io.IOException;



public class AppliServeur {

	private final static int PORT = 1234;

    public static void main(String[] args) {
        try {
            new Thread(new Serveur(serveurInversion.ServiceInversion.class, PORT)).start();
        } catch (IOException | InstantiationException | IllegalAccessException e) {
            System.err.println("Erreur demarrage server: " + e.getMessage());
        }
    }

}
