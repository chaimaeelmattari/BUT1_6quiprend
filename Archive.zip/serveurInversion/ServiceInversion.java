package serveurInversion;

import bserveur.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class ServiceInversion extends Service implements Runnable {
    private final int numero;
    public ServiceInversion() {
        super();
        this.numero = 0;
    }

    @Override
    public void run() {
        System.out.println(getClass());
        System.out.println("***********Connexion"+getSocket().getInetAddress()+" demarre");
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(getSocket().getInputStream()));
            PrintWriter out = new PrintWriter(getSocket().getOutputStream(), true);

            String message = in.readLine();
            String invertedMessage = new StringBuilder(message).reverse().toString();
            out.println(invertedMessage);

            in.close();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("************Connexion "+ this.numero + " terminee");
        try {
            getSocket().close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    @Override
    public String toString() {
        return "ServiceInversion{" +
                "socket=" + getSocket() +
                ", numero=" + numero +
                ", cpt=" +
                '}';
    }
}