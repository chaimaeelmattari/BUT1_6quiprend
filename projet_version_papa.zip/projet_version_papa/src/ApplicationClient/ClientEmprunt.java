package ApplicationClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientEmprunt {
    public static void main(String[] args) {
    	
        try {
        	// Connexion au service d'emprunt sur le port 4000
        	Socket socket = new Socket("localhost", 4000);
        	
        	// Création des flux de communication avec le serveur
        	BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        	PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        	
        	// Lecture du catalogue
            String line;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }

            // Demande à l'utilisateur de saisir le numéro de l'abonné et du DVD
            BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Entrez le numéro de l'abonné : ");
            int numAbonne = Integer.parseInt(userInput.readLine());
            System.out.println("Entrez le numéro du DVD : ");
            int numDVD = Integer.parseInt(userInput.readLine());

            // Envoi des données au service d'emprunt
            out.println(numAbonne);
            out.println(numDVD);
            
            // Récupération de la réponse du service d'emprunt
            String reponse = in.readLine();
            System.out.println(reponse);
            
            // Fermeture de la connexion
            in.close();
            out.close();
            socket.close();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
