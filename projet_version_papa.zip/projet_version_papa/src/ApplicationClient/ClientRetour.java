package ApplicationClient;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientRetour {
    public static void main(String[] args) {
    	
        try {
        	// Connexion au service de retour sur le port 5000
        	Socket socket = new Socket("localhost", 5000);
        	BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        	PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            // Affichage du catalogue de DVD
            String catalogue = in.readLine();
            System.out.println(catalogue);

            // Demande à l'utilisateur de saisir le numéro du DVD à retourner
            System.out.println("Entrez le numéro du DVD à retourner : ");
            int numDVD = Integer.parseInt(in.readLine());

            // Envoi du numéro du DVD au service de retour
            out.println(numDVD);

            // Récupération de la réponse du service de retour
            String reponse = in.readLine();
            System.out.println(reponse);

            // Fermeture de la connexion
            in.close();
            out.close();
            socket.close();
    	
        } catch (Exception e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
    }
}
