package Mediatheque;
import Mediatheque.RestrictionException;


public interface Document {

    int numero();

    /**
     * @return null si pas emprunté ou pas réservé
     */
    Abonne emprunteur();

    /**
     * @return null si pas réservé
     */
    Abonne reserveur();

    /**
     * @pre ni réservé ni emprunté
     * @throws RestrictionException si l'abonné n'est pas autorisé à réserver
     */
    void reservationPour(Abonne ab) throws RestrictionException;

    /**
     * @pre libre ou réservé par l’abonné qui vient emprunter
     * @throws RestrictionException si l'abonné n'est pas autorisé à emprunter
     */
    void empruntPar(Abonne ab) throws RestrictionException;

    /**
     * @brief retour d’un document ou annulation d‘une réservation
     */
    void retour();
}
