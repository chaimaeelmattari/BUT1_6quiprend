package Mediatheque;


public class RestrictionException extends Exception {
    public RestrictionException(String message) {
        super(message);
    }
}

