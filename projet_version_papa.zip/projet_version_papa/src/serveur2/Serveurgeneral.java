package serveur2;
import java.io.IOException;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import Mediatheque.Abonne;
import Mediatheque.DVD;
import bserveur.Serveur;


public class Serveurgeneral {

    static HashMap<Integer, Abonne> liste_abonne = new HashMap<>();
    static HashMap<Integer, DVD> liste_dvds = new HashMap<>();
    
	    public static void main(String[] args) throws IOException {
	    	
	    	//base de donnée

	    	Connection conn = null;
	    	try {
	    	    String DB_URL = "jdbc:sqlite:/Users/chaimae.elm/Desktop/mediatheque.db";
	    	    conn = DriverManager.getConnection(DB_URL); 
	    	    
	    	    //rÃ©cupÃ©ration des donnÃ©es de abonne de la BD
	    	    Statement stmt = conn.createStatement();
	    	    ResultSet rs = stmt.executeQuery("SELECT * FROM Abonne");
	    	    while (rs.next()) {
	    	    	int numAbonne = rs.getInt("numAbonne");
	    	        String nom = rs.getString("nom");
	    	        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    	    	Date date_naiss = dateFormat.parse(rs.getString("date_naiss"));
	    	    	Abonne ab = new Abonne(numAbonne, nom,date_naiss);
	    	    	
	    	    	liste_abonne.put(numAbonne, ab);
	    	    	System.out.println(ab);
	    	    
	    	    }
	    	    //rÃ©cupÃ©ration des donnÃ©es de dvd de la BD
	    	    //HashMap<Integer, DVD> liste_dvds = new HashMap<>();
	    	    
	    	    Statement stamt = conn.createStatement();
	    	    ResultSet rs2 = stamt.executeQuery("SELECT * FROM DVD");
	    	    while (rs2.next()) {
	    	        int numdvd = rs2.getInt("numdvd");
	    	        String titre = rs2.getString("titre");
	    	        Boolean adulte = rs2.getBoolean("adulte");
	    	        Abonne emprunteur = liste_abonne.get(rs2.getInt("emprunteur"));  
	    	        Abonne reserveur = null;
	    	        DVD dvd = new DVD(numdvd, titre, adulte, emprunteur,reserveur=null);
	    	        liste_dvds.put(numdvd,dvd);   
	    	        System.out.println(dvd);
	    	    }
	    	    
	    	    rs.close();
	    	    stmt.close();
	    	    rs2.close();
	    	    stamt.close(); 
	    	
	    	} catch (SQLException e) {
	    	    e.printStackTrace();} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
			} finally {
	    	    try {
	    	        if (conn != null) {
	    	            conn.close();
	    	        }
	    	    } catch (SQLException e) {
	    	        e.printStackTrace();
	    	    }}
	    	
	        // création des serveurs pour les différentes opérations
	        Serveur ServiceReservation = null;
			try {
				ServiceReservation = new Serveur(ServiceReservation.class, 3000, liste_abonne , liste_dvds);
			} catch (InstantiationException | IllegalAccessException | IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	        Serveur ServiceEmprunt = null;
			try {
				ServiceEmprunt = new Serveur(ServiceEmprunt.class, 4000,liste_abonne , liste_dvds);
			} catch (InstantiationException | IllegalAccessException | IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	        Serveur ServiceRetour = null;
			try {
				ServiceRetour = new Serveur(ServiceRetour.class, 5000, liste_abonne , liste_dvds);
			} catch (InstantiationException | IllegalAccessException | IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

	        // lancement des serveurs dans des threads séparés
	        new Thread(ServiceReservation).start();
	        //new Thread(ServiceEmprunt).start();
	        //new Thread(ServiceRetour).start();

	        // attente infinie pour maintenir les serveurs en vie
	        while (true) {
	            try {
	                Thread.sleep(1000);
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }
	    }

	
		}