package serveur2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bserveur.Service;

public class ServiceEmprunt extends Service implements Runnable {
	private static final String DB_URL = "jdbc:sqlite:C:\\mesdevs\\DB\\mediatheque.db";
	 private static final Object lock = new Object();

    @Override
    public void run() {
    	
        Connection conn = null;
        try {
        	synchronized(lock) {
      		  // Charger le pilote JDBC SQLite
              Class.forName("org.sqlite.JDBC");
              
              // Connexion à la base de données
              conn = DriverManager.getConnection(DB_URL);
      	

            // Lecture des entrées de l'utilisateur
            BufferedReader in = new BufferedReader(new InputStreamReader(getSocket().getInputStream()));
            PrintWriter out = new PrintWriter(getSocket().getOutputStream(), true);
            String query = "SELECT * FROM DVD";
            // Exécution de la requête SQL
            Statement stmt3 = conn.createStatement();
            ResultSet rs3 = stmt3.executeQuery(query);
            out.println("Voici le catalogue: ");
            while (rs3.next()) {
                int numDVD = rs3.getInt("numdvd");
                String titre = rs3.getString("titre");
                out.println("Numéro du dvd = " + numDVD + ", Titre = " + titre);
             }
            // Obtenir le numéro d'abonné
            out.println("Entrez votre numéro d'abonné : ");
            int numAbonne = Integer.parseInt(in.readLine());

            // Obtenir le numéro de DVD à réserver/emprunter
            out.println("Entrez le numéro du DVD à emprunter : ");
            int numDVD = Integer.parseInt(in.readLine());

            // Vérifier que le DVD existe
            Statement stmt0 = conn.createStatement();
            ResultSet rs0 = stmt0.executeQuery("SELECT COUNT(*) AS count FROM DVD WHERE numdvd = " + numDVD + ";");
            int dvdCount = rs0.getInt("count");
            if (dvdCount == 0) {
                out.println("Ce DVD n'existe pas.");
                in.close();
                out.close();
                getSocket().close();
                return;
            }

            // Vérifier que l'abonné existe
            Statement stmt01 = conn.createStatement();
            ResultSet rs01 = stmt01.executeQuery("SELECT COUNT(*) AS count FROM Abonne WHERE numAbonne = " + numAbonne + ";");
            int abonneCount = rs01.getInt("count");
            if (abonneCount == 0) {
                out.println("Cet abonné n'existe pas.");
                in.close();
                out.close();
                getSocket().close();
                return;
            }

            // Vérifier que le DVD est disponible ou réservé à l'abonné
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT Emprunteur, Reserveur FROM DVD WHERE numdvd = " + numDVD 
                                               + " AND (Emprunteur IS NULL OR Emprunteur = " + numAbonne + ") AND (Reserveur IS NULL OR Reserveur = " + numAbonne + ");");
            if (rs.next()) {
                int emprunteur = rs.getInt("Emprunteur");
                int reserveur = rs.getInt("Reserveur");
                if (emprunteur != 0) {
                    out.println("Ce DVD est déjà emprunté.");
                } else if (reserveur != 0) {
                    out.println("Ce DVD est réservé jusqu'à 2h.");
                } else if (reserveur == 0 && emprunteur == 0){

                	// Si le DVD a été réservé par l'abonné, il peut maintenant l'emprunter
       	         Statement stmt1 = conn.createStatement();
       	         ResultSet rs1 = stmt1.executeQuery("SELECT Reserveur FROM DVD WHERE numdvd = " + numDVD + " AND Reserveur = " + numAbonne + ";");
       	         if (rs1.next()) {
       	             stmt.executeUpdate("UPDATE DVD SET Emprunteur = " + numAbonne + ", Reserveur = NULL WHERE numdvd = " + numDVD + ";");
       	             out.println("DVD emprunté avec succès.");
       	         }

       	         // Fermer les ressources
       	         in.close();
       	         out.close();
                }}}
            } catch (IOException | ClassNotFoundException | SQLException e) {
                System.err.println(e.getClass().getName() + ": " + e.getMessage());
                System.exit(0);
            } finally {
                try {
                    if (conn != null) {
                        conn.close();
                    }
                } catch (SQLException ex) {
                    System.err.println(ex.getMessage());
                }
            }
        }
    }

