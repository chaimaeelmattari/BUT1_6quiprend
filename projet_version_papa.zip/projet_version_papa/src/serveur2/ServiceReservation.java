package serveur2;


import java.io.BufferedReader;
 
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
//import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


import Mediatheque.Abonne;
import Mediatheque.DVD;
import Mediatheque.RestrictionException;
import bserveur.Service;

public class ServiceReservation extends Service implements Runnable {
    private static final Object lock = new Object();
    static HashMap<Integer, Abonne> liste_abonne = new HashMap<>();
    static HashMap<Integer, DVD> liste_dvds = new HashMap<>();
    
    @Override
    public void run() {

    	
 
    	    try {
    	        BufferedReader in = new BufferedReader(new InputStreamReader(getSocket().getInputStream()));
    	        PrintWriter out = new PrintWriter(getSocket().getOutputStream(), true);
    	        out.println("Voici le catalogue : ");
    	        
    	        
    	        	 liste_dvds.forEach((n,d) -> {
    	    	            out.println("NumÃ©ro du dvd : " + n + "  Titre du dvd : " + d.getTitre());
    	    	        });
    	        
    	       
    	        
    	        out.println("\nEntrez votre numÃ©ro d'abonnÃ© : ");
    	        int numab = Integer.parseInt(in.readLine());
    	        //Abonne abonne = Abonne.intToAbonne(numab);
    	        
    	        out.println("\nEntrez le numÃ©ro du DVD Ã  rÃ©server : ");
    	        int numDVD = Integer.parseInt(in.readLine());
    	        
    	        // RÃ©servation du DVD si possible
    	        if (liste_dvds.containsKey(numDVD)) {
    	            DVD dvd = liste_dvds.get(numDVD);
    	            out.println(dvd);
    	            dvd.reservationPour(liste_abonne.get(numab));

    	        } else {
    	            out.println("Ce DVD n'existe pas.");
    	        }
    	    } catch (IOException e) {
    	        e.printStackTrace();
    	    } catch (RestrictionException e) {
    	        e.printStackTrace();
    	    } 
    
		}}

    	
    	
		             
		            
		             
	    
	






		











		



