package serveur2;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bserveur.Service;

public class ServiceRetour extends Service implements Runnable {
    private static final Object lock = new Object();
    private static final String DB_URL = "jdbc:sqlite:C:\\mesdevs\\DB\\mediatheque.db";

    @Override
    public void run() {
        Connection conn = null;
        try {
            synchronized(lock) {
                // Charger le pilote JDBC SQLite
                Class.forName("org.sqlite.JDBC");
                
                // Connexion à la base de données
                conn = DriverManager.getConnection(DB_URL);
            

            // Lecture des entrées de l'utilisateur
            BufferedReader in = new BufferedReader(new InputStreamReader(getSocket().getInputStream()));
            PrintWriter out = new PrintWriter(getSocket().getOutputStream(), true);
            String query = "SELECT * FROM DVD";
            // Exécution de la requête SQL
            Statement stmt1 = conn.createStatement();
            ResultSet rs1 = stmt1.executeQuery(query);
            out.println("Voici le catalogue: ");
            while (rs1.next()) {
                int numDVD = rs1.getInt("numdvd");
                String titre = rs1.getString("titre");
                out.println("Numéro du dvd = " + numDVD + ", Titre = " + titre);
             }
            out.println("Entrez le numéro du DVD à retourner : ");
            int numDVD = Integer.parseInt(in.readLine());

            // Vérifier que le DVD est emprunté
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT Emprunteur FROM DVD WHERE numdvd = " + numDVD);
            if (rs.next()) {
                int emprunteur = rs.getInt("Emprunteur");
                if (emprunteur != 0) {
                    // Mettre à jour la table DVD pour indiquer que le DVD a été rendu
                    stmt.executeUpdate("UPDATE DVD SET Emprunteur = NULL WHERE numdvd = " + numDVD + ";");
                    out.println("DVD retourné avec succès.");
                } else {
                    out.println("Ce DVD n'a pas été emprunté.");
                }
            } else {
                out.println("Ce DVD n'existe pas.");
            }

            in.close();
            out.close();}
        } catch (IOException | ClassNotFoundException | SQLException e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex.getMessage());
            }
        }
    }
}
