package Mediatheque;

//import java.sql.Date;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.Date;

public class Abonne {
    private int numAbonne;
    private String nom;
    private Date dateNaissance;

    // constructeur
    public Abonne(int numAbonne, String nom, Date date) {
        this.numAbonne = numAbonne;
        this.nom = nom;
        this.dateNaissance = date;
    }

    // getters et setters
    public int getNumAbonne() {
        return numAbonne;
    }

    public void setNumAbonne(int numAbonne) {
        this.numAbonne = numAbonne;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Date getDateNaissance() {
        return dateNaissance;
    }

    public void setDateNaissance(Date dateNaissance) {
        this.dateNaissance = dateNaissance;
    }

	public int getage() {
		// TODO Auto-generated method stub
		Date now = new Date();  
		DateFormat formatter = new SimpleDateFormat("yyyyMMdd");                           
	    int d1 = Integer.parseInt(formatter.format(dateNaissance));                            
	    int d2 = Integer.parseInt(formatter.format(now));                          
	    int age = (d2 - d1) / 10000;                                                       
	    return age;
	}
	
	//changer numabonne en objet abonne
	public static Abonne intToAbonne(int numAbonne) {
	    return new Abonne(numAbonne, null, null);
	}


    // méthode pour calculer l'âge de l'abonné
	/*public int calculateAge(
			  Date dateNaissance, 
			  Date currentDate) {            
			    // validate inputs ...                                                                               
			    DateFormat formatter = new SimpleDateFormat("yyyyMMdd");                           
			    int d1 = Integer.parseInt(formatter.format(dateNaissance));                            
			    int d2 = Integer.parseInt(formatter.format(currentDate));                          
			    int age = (d2 - d1) / 10000;                                                       
			    return age;                                                                        
			}*/
	 public String toString() {
	    	return  "Num Abonné : '" +  this.numAbonne +  "', Nom: '" + this.nom + "', Date de naissance : '" + this.dateNaissance + "'; Age: " + this.getage() +  "'";
	    	}
}
