package Mediatheque;

import java.util.Date;
import Mediatheque.RestrictionException;


public class DVD implements Document {

    private int numdvd;
    private String titre;
    private boolean adulte;
    private Abonne emprunteur;
    private Abonne reserveur;
    private Date date_reservation=null; 

    public DVD(int numdvd, String titre, boolean adulte, Abonne emprunteur, Abonne reserveur) {
        this.numdvd = numdvd;
        this.titre = titre;
        this.adulte = adulte;
        this.emprunteur = emprunteur;
        this.reserveur = reserveur;
        //this.date_reservation = date_reservation;
    }


	public int numero() {
        return numdvd;
    }

    public Abonne emprunteur() {
    	if(emprunteur==null ){
    		return null;
    	}
    	else return emprunteur;
    }

    public Abonne reserveur() {
    	if(reserveur == null)
    		return null;
    	else return reserveur;
    }

    public void reservationPour(Abonne ab) throws RestrictionException {
        if (reserveur() == null && emprunteur() == null) {
        	if  (adulte && ab.getage()< 16) {
        		throw new RestrictionException("DVD réservé aux plus de 16 ans");
        	}
        	else 
	        	System.out.println(ab);
	        	this.reserveur = ab;
	        	System.out.println("DVD réservé avec succès. Vous avez 2h pour venir l'emprunter.");
        }
        else throw new RestrictionException("DVD réservé ou emprunté");
        
    }

    public void empruntPar(Abonne ab) throws RestrictionException {
    	if (emprunteur == null && reserveur.equals(ab)) {
    		emprunteur=ab;
    		reserveur = null;
    	}
    	else if (emprunteur != null && !emprunteur.equals(ab) || reserveur != null && !reserveur.equals(ab)) {
    		throw new RestrictionException("DVD réservé ou emprunté par un autre abonné");
    	}
   
    	else if (adulte && ab.getage()< 16) {
    		throw new RestrictionException("DVD réservé aux plus de 16 ans");
    	}
    }

    public void retour() {
    	if (emprunteur != null) {
    		emprunteur = null;
    	}
    	
    }

    public boolean isAdulte() {
    	if(adulte = true ) {
    		return adulte;}
		return false;
		
        
    }

    public String getTitre() {
        return titre;
    }


    public String toString() {
    	return  "Num dvd : '" +  this.numdvd +  "', titre: '" + this.titre + "', Categorie: '" + this.adulte + "', Emprunteur: '" + this.emprunteur + "', Reserveur: '" + this.reserveur + "'";
    	}







}
