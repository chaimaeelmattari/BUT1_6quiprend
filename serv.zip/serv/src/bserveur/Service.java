package bserveur;

import java.io.IOException;
import java.net.Socket;

public abstract class Service implements Runnable{

    private Socket socket;
    public Service() {}
    protected Socket getSocket(){
        return socket;
    }


    public void close(){
        try {
            this.socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void setSocket(java.net.Socket newSocket) {
        socket = newSocket;
    }

    @Override
    public abstract void run();
}