package serveurInversion;
import bserveur.Serveur;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import Mediatheque.Abonne;
import Mediatheque.DVD;



public class AppliServeur {

	private final static int PORT = 3000;
	static  HashMap<Integer, Abonne> liste_abonne = new HashMap<>(); 
	static HashMap<Integer, DVD> liste_dvds = new HashMap<>();
	 private static AppliServeur instance = null;
	
    public static void main(String[] args) {
    
    	//base de donnée

    	Connection conn = null;
    	try {
    	    String DB_URL = "jdbc:sqlite:/Users/chaimae.elm/Desktop/mediatheque.db";
    	    conn = DriverManager.getConnection(DB_URL); 
    	    
    	    //rÃ©cupÃ©ration des donnÃ©es de abonne de la BD
    	    Statement stmt = conn.createStatement();
    	    ResultSet rs = stmt.executeQuery("SELECT * FROM Abonne");
    	    
    	    while (rs.next()) {
    	    	int numAbonne = rs.getInt("numAbonne");
    	        String nom = rs.getString("nom");
    	        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    	    	Date date_naiss = dateFormat.parse(rs.getString("date_naiss"));
    	    	Abonne ab = new Abonne(numAbonne, nom,date_naiss);
    	    	liste_abonne.put(numAbonne, ab);

    	    	//System.out.println(ab);
    	    
    	    }
    	    //rÃ©cupÃ©ration des donnÃ©es de dvd de la BD
    	    //HashMap<Integer, DVD> liste_dvds = new HashMap<>();
    	    
    	    Statement stamt = conn.createStatement();
    	    ResultSet rs2 = stamt.executeQuery("SELECT * FROM DVD");
    	    while (rs2.next()) {
    	        int numdvd = rs2.getInt("numdvd");
    	        String titre = rs2.getString("titre");
    	        Boolean adulte = rs2.getBoolean("adulte");
    	        Abonne emprunteur = liste_abonne.get(rs2.getInt("emprunteur"));  
    	        Abonne reserveur = null;
    	        DVD dvd = new DVD(numdvd, titre, adulte, emprunteur,reserveur=null);
    	        liste_dvds.put(numdvd,dvd); 
    	       
    	        //System.out.println(dvd);
    	    }
    	    
    	    rs.close();
    	    stmt.close();
    	    rs2.close();
    	    stamt.close(); 
    	
    	} catch (SQLException e) {
    	    e.printStackTrace();} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		} finally {
    	    try {
    	        if (conn != null) {
    	            conn.close();
    	        }
    	    } catch (SQLException e) {
    	        e.printStackTrace();
    	    }}
    	
        try {
            new Thread(new Serveur(serveurInversion.ServiceInversion.class, PORT, liste_abonne, liste_dvds)).start();
        } catch (IOException | InstantiationException | IllegalAccessException e) {
            System.err.println("Erreur demarrage server: " + e.getMessage());
        }
    }


	    public static AppliServeur getInstance() {
	        if (instance == null) {
	            instance = new AppliServeur();
	        }
	        return instance;
	    }


	    public Map<Integer, Abonne> getListeAbonne() {
	        return liste_abonne;
	    }

	}

