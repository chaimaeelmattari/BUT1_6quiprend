package serveurInversion;

import bserveur.Service;
import bserveur.Serveur;
import serveurInversion.AppliServeur;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Map;

import Mediatheque.Abonne;

public class ServiceInversion extends Service implements Runnable {
    private final int numero;
    public ServiceInversion() {
        super();
        this.numero = 0;
    }
   
   AppliServeur appserveur = AppliServeur.getInstance();
    Map<Integer, Abonne> liste_abonne = appserveur.getListeAbonne();


    @Override
    public void run() {
        System.out.println(getClass());
        System.out.println("***********Connexion"+getSocket().getInetAddress()+" demarre");
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(getSocket().getInputStream()));
            PrintWriter out = new PrintWriter(getSocket().getOutputStream(), true);

            out.println("\nEntrez votre numÃ©ro d'abonnÃ© : ");
	        int numab = Integer.parseInt(in.readLine());
	        
	        out.println(" --> " +liste_abonne);
	        
            

            in.close();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("************Connexion "+ this.numero + " terminee");
        try {
            getSocket().close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}